<div id="sendgrid_statistics_engagement_widget" class="postbox">
  <h3 class="hndle"><span>SendGrid Engagement</span></h3>
  <div class="inside">

    <div class="sendgrid-container" style="position:relative;">
      <img src="<?php echo plugin_dir_url( __FILE__ ); ?>../images/loader.gif" class="loading" style="position:absolute;" />
      <div id="engagement-container" class="sendgrid-statistics"></div>
    </div>
    <div id="engagement-container-legend" class="sendgrid-statistics-legend"></div> 

  </div>
</div>
